package Array.ArrayOperation;

import java.util.Arrays;

public class MyArray {
    private final int initialLength=10;
    private int[] array=new int[initialLength];

    public MyArray(){
        for(int i =0; i< array.length;i++){
            array[i]=0;
        }
    }

    public void insert(int index,int value){
        int[] arrayNew=new int[array.length+1];
        arrayNew = Arrays.copyOf(array, array.length + 1);
        if(index== array.length-1){
            arrayNew[array.length]=value;
        }
        else if(index>=0 && index< array.length-1) {
            for (int i = array.length-1; i>=index ; i--) {
                arrayNew[i+1]=arrayNew[i];
            }
            arrayNew[index]=value;
        }
        else {
            System.out.println("wrong index, please input again");
        }
        array=arrayNew;
    }

    public void delete(int index){
        for (int i = index; i <= array.length-2; i++) {
            array[i]=array[i+1];
        }
        int[] arrayNew=new int[array.length-1];
        for (int i = 0; i < array.length - 2; i++) {
            arrayNew[i]=array[i];
        }
        array=arrayNew;
    }

    @Override
    public String toString() {
        return "MyArray{" +
                "array=" + Arrays.toString(array) +
                '}';
    }
}
